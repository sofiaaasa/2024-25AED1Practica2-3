#ifndef _DICPAGINAS_H
#define _DICPAGINAS_H

#include "Pagina.h"
#include <list>
#include <iostream>
using namespace std;

class DicPaginas{
  private:
    int contador = 0;
    list<Pagina> lista;
  public:
    void insertar(Pagina &nueva);
    Pagina consultar(string url);
    int getNumElem() { return contador;};
};

#endif
