#include "DicPaginas.h"

void DicPaginas::insertar(Pagina &nueva){
  list<Pagina>::iterator it = lista.begin();
  while (it != lista.end() && *it < nueva) it++;
  if (it == lista.end() || *it != nueva) {
    lista.insert(it, nueva);
    contador++;
  }
  else if (*it == nueva) *it = nueva;
}

Pagina DicPaginas::consultar(string url){
  list<Pagina>::iterator it = lista.begin();
  while (it != lista.end() && (*it).getUrl() < url) it++;
  if (it != lista.end() && (*it).getUrl() == url) return *it;
  Pagina por_defecto = Pagina();
  return por_defecto;
}

