#ifndef _PAGINA_H
#define _PAGINA_H

#include <iostream>
using namespace std;

class Pagina{
  private:
    int relevancia;
    string url, titulo;
  public:
    Pagina();
    Pagina(int relevancia, string url, string titulo);
    bool operator< (Pagina &pagina2);
    bool operator> (Pagina &pagina2);
    bool operator== (Pagina &pagina2);
    bool operator!= (Pagina &pagina2);
    int getRelevancia();
    string getUrl();
    string getTitulo();
};

#endif
