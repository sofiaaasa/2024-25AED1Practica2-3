#include "DicPaginas.h"

void DicPaginas::insertar(Pagina &nueva){
  tabla.insertar(nueva);
}

Pagina DicPaginas::consultar(string url){
  return tabla.consultar(url);
}

int DicPaginas::getNumElem(){
  return tabla.getNumElem();
}

