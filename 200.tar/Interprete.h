#ifndef _INTERPRETE_H
#define _INTERPRETE_H

#include "DicPaginas.h"
#include <iostream>
using namespace std;

class Interprete{
  private:
    const int tilde = -61;
    static const int NUM_TILDES = 7;
    const int tablaTil[2][NUM_TILDES] = {{-79, -95, -87, -83, -77, -70, -68},        //ñ á é í ó ú ü
                            {-111, -127, -119, -115, -109, -102, -100}};  //Ñ Á É Í Ó Ú Ü
    const string tablaSin[NUM_TILDES] = {"ñ", "a", "e", "i", "o", "u", "u"};  //ñ a e i o u
    DicPaginas dic;
    string normalizar(string cadena);
  public:
    int interpretar(string comando);
    void insertar();
};

#endif
