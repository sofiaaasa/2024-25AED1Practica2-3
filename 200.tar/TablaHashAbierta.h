#ifndef _TABLAHASHABIERTA_H
#define _TABLAHASHABIERTA_H

#include "Pagina.h"
#include <iostream>
#include <list>
#include <cmath>
using namespace std;

class TablaHashAbierta {
  private:
    list<Pagina>* tabla;
    static const int TAMANO_INICIAL = 9473;   //Mirando la salida, la tablaHash tendrá 18940 elementos y para que funcione bien una tabla de dispersión abierta, se necesita que nelem < 2*ncub, lo que daría un tamaño máximo de cubetas de 9473
    int nelem;
    int ncub;
    int siguienteNumPrimo(int numero);
    int fdispersion (string cadena, int numCub);
    void reestructurar();
  public:
    TablaHashAbierta();
    ~TablaHashAbierta();
    int getNumElem();
    void insertar(Pagina &nueva);
    Pagina consultar(string url);
};

#endif
