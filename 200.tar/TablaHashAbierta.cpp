#include "TablaHashAbierta.h"

TablaHashAbierta::TablaHashAbierta(){
  ncub = TAMANO_INICIAL;
  nelem = 0;
  tabla = new list<Pagina>[TAMANO_INICIAL];
}

TablaHashAbierta::~TablaHashAbierta(){
  delete[] tabla;
}

//siguienteNumPrimo asume que siempre se le va a meter como parámetro un número primo mayor a 2, por lo que siempre será impar. 
int TablaHashAbierta::siguienteNumPrimo(int numero) {
  numero = 2*numero +1;  //Nos saltamos el número par que va justo detrás del doble del número primo metido como parámetro
  bool primo = false;
  while (! primo){
    primo = true;
    int i=3;
    while (i<=sqrt(numero) && primo){  
      if (numero%i == 0 || numero%(i + 2) == 0) primo = false;  //Saltamos los pares
      i+=4; //Saltamos los pares
    }
    if (! primo) numero+=2;   //Saltamos los pares
  }
  return numero;
}

int TablaHashAbierta::fdispersion (string cadena, int numCub){
  unsigned long res = 5381;   //Es el valor inicial de djb2a
  for (char c : cadena) {
        res = ((res << 5) + res) ^ c;   //Desplaza 5 bits a la izquierda res y después le suma res y hace el XOR del resultado de la suma. Se hace para mayor uniformidad
  }
  return res%numCub;
}

void TablaHashAbierta::reestructurar(){
  int tamanyo = siguienteNumPrimo(2*ncub);
  list<Pagina>* tablanueva = new list<Pagina>[tamanyo];
  for (int i=0; i<ncub; i++){
    list<Pagina>::iterator it = tabla[i].begin();
    while (it != tabla[i].end()){
      int cubeta = fdispersion((*it).getUrl(), tamanyo);
      list<Pagina>::iterator itnueva = tablanueva[cubeta].begin();
      while (itnueva != tablanueva[cubeta].end() && *itnueva < *it) itnueva++;
      if (itnueva == tablanueva[cubeta].end() || *itnueva != *it) {
        tablanueva[cubeta].insert(itnueva, *it);
	//contador++;
      }
      else if (*itnueva == *it) *itnueva = *it;
      it++;
    }
  }
  delete[] tabla;
  tabla = tablanueva;
  ncub = tamanyo;
}

void TablaHashAbierta::insertar(Pagina &nueva){
  if (nelem > 2*ncub) reestructurar();
  int cubeta = fdispersion(nueva.getUrl(), ncub);
  list<Pagina>::iterator it = tabla[cubeta].begin();
  while (it != tabla[cubeta].end() && *it < nueva) it++;
  if (it == tabla[cubeta].end() || *it != nueva) {
    tabla[cubeta].insert(it, nueva);
    nelem++;
  }
  else if (*it == nueva) *it = nueva;
}

Pagina TablaHashAbierta::consultar(string url){
  int cubeta = fdispersion(url, ncub);
  list<Pagina>::iterator it = tabla[cubeta].begin();
  while (it != tabla[cubeta].end() && (*it).getUrl() < url) it++;
  if (it != tabla[cubeta].end() && (*it).getUrl() == url) return *it;
  Pagina por_defecto = Pagina();
  return por_defecto;
}

int TablaHashAbierta::getNumElem(){ return nelem;}
