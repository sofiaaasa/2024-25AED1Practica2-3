#include "Interprete.h"
#include <iostream>
#include <string>
using namespace std;

int main(){
  Interprete i;
  string palabra;
  while (cin >> palabra){
    if(i.interpretar(palabra)) return 0;
  }
  return 0;
}
