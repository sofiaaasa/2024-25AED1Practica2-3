#ifndef _DICPAGINAS_H
#define _DICPAGINAS_H

#include "TablaHashAbierta.h"
#include <list>
#include <iostream>
using namespace std;

class DicPaginas{
  private:
    TablaHashAbierta tabla;
  public:
    void insertar(Pagina &nueva);
    Pagina consultar(string url);
    int getNumElem();
};

#endif
