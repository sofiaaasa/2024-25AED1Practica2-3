#include "Pagina.h"

Pagina::Pagina() {
  this->relevancia = 1;
  this->url = "url";
  this->titulo = "titulo";
}

Pagina::Pagina(int relevancia, string url, string titulo) {
  this->relevancia = relevancia;
  this->url = url;
  this->titulo = titulo;
}

bool Pagina::operator< (Pagina &pagina2){
  return url < pagina2.url;
}
bool Pagina::operator> (Pagina &pagina2){
  return url > pagina2.url;
}
bool Pagina::operator== (Pagina &pagina2){
  return url == pagina2.url;
}
bool Pagina::operator!= (Pagina &pagina2){
  return url != pagina2.url;
}


int Pagina::getRelevancia(){ return relevancia;};
string Pagina::getUrl(){ return url;};
string Pagina::getTitulo(){ return titulo;};

