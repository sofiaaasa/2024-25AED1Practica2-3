#include "Interprete.h"

string Interprete::normalizar(string cadena){
  string cad = cadena;
  string normalizada = "";
  for (unsigned i=0; i<cad.length(); i++){         
    if (cad[i] >= 'A' && cad[i] <= 'Z') normalizada+=tolower(cad[i]);   // Letras mayúsculas sin tildes
    else if (int(cadena[i]) == tilde){                      // Comprueba si el código decimal del carácter corresponde a una letra con tilde.
      int j=0;
      bool continuar = true;
      while (j<NUM_TILDES && continuar){    // Va buscando cual es la letra con tilde que hay
        if (int(cad[i+1]) == tablaTil[0][j] || int(cad[i+1]) == tablaTil[1][j]){     
          normalizada+=tablaSin[j];
          continuar = false;
          i++;
        }
        j++;
      }
      if (continuar == true) normalizada+=cad[i]; //Por si es cualquier carácter raro que use 2 bytes en vez de 1 pero que no esté en la tabla
    } else normalizada+=cad[i];     
  }
  return normalizada;
}


int Interprete::interpretar (string comando){
  if (comando == "i") insertar();
  else if (comando == "s"){
    cin.ignore();
    if (cin.peek() == -1) cout << "Saliendo..." << endl;  
    return 1;
  } 
  else if (comando == "u") {
    string url;
    cin.ignore();
    getline(cin, url);
    Pagina p = dic.consultar(url);
    Pagina por_defecto = Pagina();
    cout << comando << " " << url << endl;
    if (p != por_defecto){
      cout << "1. " << p.getUrl() << ", " << p.getTitulo() << ", Rel. " << p.getRelevancia() << endl;
      cout << "Total: 1 resultados" << endl;
    } else {
      cout << "Total: 0 resultados" << endl;
    }
  }
  else if (comando == "b") {
    string palabra;
    cin >> palabra;
    cout << comando << " " << normalizar(palabra) << endl;
    cout << "Total: 0 resultados" << endl;
  }
  else if (comando == "a") {
    string palabras;
    cin.ignore();
    getline(cin, palabras);
    cout << comando << " " << normalizar(palabras) << endl;
    cout << "Total: 0 resultados" << endl;
  }
  else if (comando == "o") {
    string palabras;
    cin.ignore();
    getline(cin, palabras);
    cout << comando << " " << normalizar(palabras) << endl;
    cout << "Total: 0 resultados" << endl;
  }
  else if (comando == "p") {
    string palabra;
    cin >> palabra;
    cout << comando << " " << normalizar(palabra) << endl;
    cout << "Total: 0 resultados" << endl;
  }
  return 0;
}


void Interprete::insertar(){
  int relevancia;
  int numpal = 0;
  string palabra, URL, titulo;
  cin >> relevancia >> URL;
  cin.ignore();
  getline(cin, titulo);
  
  Pagina nueva(relevancia, URL, titulo);
  dic.insertar(nueva);
  
  cout << dic.getNumElem() << ". " << URL << ", " << titulo << ", Rel. " << relevancia << endl;
  while (cin >> palabra && normalizar(palabra) != "findepagina" ){
    numpal+=1;
  }
  cout << numpal << " palabras" << endl;
}

